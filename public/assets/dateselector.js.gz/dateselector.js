$(function() {
	$(".datepicker").datepicker();
});
